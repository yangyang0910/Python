# -*- coding:utf-8 -*-
# AUTHER   @ Alvin
# import sys
# for i in sys.path:
#     print(i)
# import os
#
# print(os.path.dirname(__file__))
# print(help('module'))
#

import time

# print(time.time())
#
# print(time.struct_time)
#
# print("AA")
#
# print(time.asctime())
#
# print(time.ctime())

print(time.strftime("%a %p %U %w %y %z %Z %Y-%m-%d %H:%M:%S"))