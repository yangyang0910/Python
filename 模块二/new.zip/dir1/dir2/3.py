# -*- coding:utf-8 -*-
# AUTHER   @ Alvin
print(111)